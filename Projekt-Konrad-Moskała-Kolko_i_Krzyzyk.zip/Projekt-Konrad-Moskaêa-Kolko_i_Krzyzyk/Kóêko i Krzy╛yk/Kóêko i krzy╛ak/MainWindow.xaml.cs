﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Kółko_i_krzyżak
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public bool TuraGraczaPierwszego { get; set; }
        public int Licznik { get; set; }

        public MainWindow()
        {
            InitializeComponent();

            NowaGra();
        }

        public void NowaGra()
        {
            TuraGraczaPierwszego = false;
            Licznik = 0;

            Guzik_0_0.FontSize = 100;
            Guzik_1_0.FontSize = 100;
            Guzik_2_0.FontSize = 100;
            Guzik_0_1.FontSize = 100;
            Guzik_1_1.FontSize = 100;
            Guzik_2_1.FontSize = 100;
            Guzik_0_2.FontSize = 100;
            Guzik_1_2.FontSize = 100;
            Guzik_2_2.FontSize = 100;

            Guzik_0_0.Foreground = Brushes.White;
            Guzik_1_0.Foreground = Brushes.White;
            Guzik_2_0.Foreground = Brushes.White;
            Guzik_0_1.Foreground = Brushes.White;
            Guzik_1_1.Foreground = Brushes.White;
            Guzik_2_1.Foreground = Brushes.White;
            Guzik_0_2.Foreground = Brushes.White;
            Guzik_1_2.Foreground = Brushes.White;
            Guzik_2_2.Foreground = Brushes.White;
                    
            Guzik_0_0.Content = String.Empty;
            Guzik_1_0.Content = String.Empty;
            Guzik_2_0.Content = String.Empty;
            Guzik_0_1.Content = String.Empty;
            Guzik_1_1.Content = String.Empty;
            Guzik_2_1.Content = String.Empty;
            Guzik_0_2.Content = String.Empty;
            Guzik_1_2.Content = String.Empty;
            Guzik_2_2.Content = String.Empty;

            Guzik_0_0.Background = Brushes.Black;
            Guzik_1_0.Background = Brushes.Black;
            Guzik_2_0.Background = Brushes.Black;
            Guzik_0_1.Background = Brushes.Black;
            Guzik_1_1.Background = Brushes.Black;
            Guzik_2_1.Background = Brushes.Black;
            Guzik_0_2.Background = Brushes.Black;
            Guzik_1_2.Background = Brushes.Black;
            Guzik_2_2.Background = Brushes.Black;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (TuraGraczaPierwszego) //kogo jest tura
                TuraGraczaPierwszego = false;
            else
                TuraGraczaPierwszego = true; 
            Licznik++;

            if (Licznik > 9)
            {
                NowaGra();
                return;
            }
                

            var guzik = sender as Button;

            // gracz pierwszy = 0 , gracz drugi = X
            guzik.Content = TuraGraczaPierwszego ? "O" : "X"; //kogo jest tura, co ma wyświetlać X lub O

            //Sprawdzanie wygranego
            if (SprawdzeniaCzyWygrał())
            {
                Licznik = 9;
            }
           

        }

        //Przypadki w których ktoś wygrywa
        private bool SprawdzeniaCzyWygrał()
        {
            //Rząd 1
            if (Guzik_0_0.Content.ToString() != string.Empty && Guzik_0_0.Content == Guzik_0_1.Content && Guzik_0_1.Content  == Guzik_0_2.Content)
            {
                Guzik_0_0.Background = Brushes.Green;
                Guzik_0_1.Background = Brushes.Green;
                Guzik_0_2.Background = Brushes.Green;
                return true;
            }
            //Rząd 2 
            if (Guzik_1_0.Content.ToString() != string.Empty &&  Guzik_1_0.Content == Guzik_1_1.Content && Guzik_1_1.Content == Guzik_1_2.Content)
            {
                Guzik_1_0.Background = Brushes.Green;
                Guzik_1_1.Background = Brushes.Green;
                Guzik_1_2.Background = Brushes.Green;
                return true;
            }
            //Rząd 3
            if (Guzik_2_0.Content.ToString() != string.Empty &&  Guzik_2_0.Content == Guzik_2_1.Content && Guzik_2_1.Content == Guzik_2_2.Content)
            {
                Guzik_2_0.Background = Brushes.Green;
                Guzik_2_1.Background = Brushes.Green;
                Guzik_2_2.Background = Brushes.Green;
                return true;
            }
            //Kolumna 1
            if (Guzik_0_0.Content.ToString() != string.Empty &&  Guzik_0_0.Content == Guzik_1_0.Content && Guzik_1_0.Content == Guzik_2_0.Content)
            {
                Guzik_0_0.Background = Brushes.Green;
                Guzik_1_0.Background = Brushes.Green;
                Guzik_2_0.Background = Brushes.Green;
                return true;
            }
            //Kolumna 2
            if (Guzik_0_1.Content.ToString() != string.Empty &&  Guzik_0_1.Content == Guzik_1_1.Content && Guzik_1_1.Content == Guzik_2_1.Content)
            {
                Guzik_0_1.Background = Brushes.Green;
                Guzik_1_1.Background = Brushes.Green;
                Guzik_2_1.Background = Brushes.Green;
                return true;
            }
            //Kolumna 3
            if (Guzik_0_2.Content.ToString() != string.Empty &&  Guzik_0_2.Content == Guzik_1_2.Content && Guzik_1_2.Content == Guzik_2_2.Content)
            {
                Guzik_0_2.Background = Brushes.Green;
                Guzik_1_2.Background = Brushes.Green;
                Guzik_2_2.Background = Brushes.Green;
                return true;
            }
            //Przekątna 1 
            if (Guzik_0_0.Content.ToString() != string.Empty &&  Guzik_0_0.Content == Guzik_1_1.Content && Guzik_1_1.Content == Guzik_2_2.Content)
            {
                Guzik_0_0.Background = Brushes.Green;
                Guzik_1_1.Background = Brushes.Green;
                Guzik_2_2.Background = Brushes.Green;
                return true;
            }
            //Przekątna 2
            if (Guzik_0_2.Content.ToString() != string.Empty &&  Guzik_0_2.Content == Guzik_1_1.Content && Guzik_1_1.Content == Guzik_2_0.Content)
            {
                Guzik_0_2.Background = Brushes.Green;
                Guzik_1_1.Background = Brushes.Green;
                Guzik_2_0.Background = Brushes.Green;
                return true;
            }

            return false;
        }
    }
}
